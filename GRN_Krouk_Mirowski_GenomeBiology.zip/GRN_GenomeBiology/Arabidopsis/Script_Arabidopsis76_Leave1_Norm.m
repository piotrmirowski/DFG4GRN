% Leave-out-last analysis, 76 genes, RMA data
% gradient state-space optimization of kinetic equation, linear dynamics
% no data normalization

% Call default script
Script_Arabidopsis76_Leave1;

% Normalize the data
params.normalize_data = 1;
